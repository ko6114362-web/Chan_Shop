CHAN SHOP Android App

Features
- Myanmar clothing shop interface
- Add products with name, price, category, emoji and a photo selected from phone gallery
- Product photos are resized and saved in this app on this phone
- Shopping cart and customer delivery details
- KBZPay payment details: 09798636215 / Daw Khin Soe Win
- Share order text using Android share menu

Important
Product names, prices and photos are stored locally on the phone that adds them. They do not automatically synchronize to customers' phones. A shared online store needs a backend/database and image hosting.

GitHub Actions
Upload this project ZIP to the repository and run the build workflow. Download the CHAN-SHOP-APK artifact after the workflow succeeds.

App icon: Chan shopping-bag logo is configured as the Android launcher icon.


Cloud order setup: See FIREBASE_SETUP_MM.txt and FIREBASE_DATABASE_RULES.json.
