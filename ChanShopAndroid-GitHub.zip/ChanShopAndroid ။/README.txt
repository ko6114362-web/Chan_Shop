CHAN SHOP Android App - GitHub Actions APK build

ဒီ project ကို GitHub သို့တင်ပြီး APK ကို အလိုအလျောက် build လုပ်နိုင်ရန် workflow ထည့်ထားသည်။

ဖုန်းမှ GitHub အသုံးပြု၍ APK ထုတ်ရန်:
1. GitHub account ဝင်ပါ။ New repository ဖန်တီးပါ။ ဥပမာ repository name: chan-shop
2. Repository ကို Public သို့မဟုတ် Private ရွေးနိုင်သည်။ Create repository နှိပ်ပါ။
3. ဒီ ZIP ကို ဖြည်ပြီး ChanShopAndroid folder ထဲက ဖိုင်/ဖိုလ်ဒါအားလုံးကို repository ၏ main folder (root) ထဲ Upload files ဖြင့်တင်ပါ။ .github ဖိုလ်ဒါအပါအဝင် တင်ရမည်။
4. Commit changes နှိပ်ပါ။
5. Repository ထဲက Actions tab ကိုဖွင့်ပါ။ "Build CHAN SHOP APK" workflow ကိုရွေးပါ။
6. အလိုအလျောက်မစတင်ပါက Run workflow > Run workflow နှိပ်ပါ။
7. Build အောင်မြင်သွားလျှင် workflow run ထဲက Artifacts အောက်ရှိ CHAN-SHOP-APK ကို Download လုပ်ပါ။
8. ZIP ကိုဖုန်းထဲဖြည်ပြီး app-debug.apk ကိုနှိပ်ကာ Install လုပ်ပါ။ Android က မေးလျှင် ဒီရင်းမြစ်မှ app install ခွင့်ပြုပါ။

မှတ်ချက်:
- GitHub Actions သည် internet ချိတ်ထားသည့်အခါ build လုပ်သည်။
- APK သည် debug APK ဖြစ်ပြီး ကိုယ်ပိုင်စမ်းသပ်အသုံးပြုရန်ဖြစ်သည်။ Public Play Store ထုတ်ဝေရန် signed release build လိုအပ်သည်။
- KBZPay အချက်အလက်ကို ပြသပေးခြင်းသာဖြစ်ပြီး KBZPay အလိုအလျောက်ငွေလက်ခံ/စစ်ဆေးမှု မပါဝင်ပါ။
- ပစ္စည်းများမှာ နမူနာဖြစ်ပြီး App ထဲတွင် ပြင်ဆင်/ထပ်ထည့်နိုင်သည်။
