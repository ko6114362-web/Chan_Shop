# CHAN SHOP Customer App

Separate Android customer app.

- App name: CHAN SHOP Customer
- Package: `com.chanshop.customer`
- Owner app package: `com.chanshop.app`
- Firebase Realtime Database: `https://chan-shop-default-rtdb.asia-southeast1.firebasedatabase.app`
- Product path: `/products`
- Orders: `/orders` and `/customerOrders/{customerUid}`
- KPay: 09798636215 — Daw Khin Soe Win

## Included features

- Customer registration/login using phone-number-shaped email + password (no SMS OTP)
- Firebase refresh-token session persistence: stays logged in after closing/reopening the app until the user taps Logout or Firebase revokes the session
- Refresh button and pull-down-to-refresh
- Products, cart, checkout, order history
- KPay account details and copy-number action
- Purple/pink CHAN SHOP styling and CHAN shopping icon
- GitHub Actions workflow to build the APK

## Build on GitHub

1. Create a new GitHub repository for the customer app.
2. Extract this ZIP and upload all files/folders inside `CHAN_SHOP_Customer_GitHub` to the repository root (not the ZIP file itself).
3. Open the repository's **Actions** tab.
4. Select **Build CHAN SHOP Customer APK** and press **Run workflow** (or push a commit).
5. Open the completed workflow, then download the **CHAN-SHOP-Customer-APK** artifact.
6. Extract the artifact ZIP to get `app-debug.apk`.

## Important Firebase notes

- Firebase Authentication must have Email/Password enabled.
- The app uses a phone number converted to an internal synthetic email address. This does **not** verify that the customer owns that phone number; it is not SMS Phone Authentication.
- The included `firebase-database-rules-example.json` is a starting ruleset for this exact app data layout. Review it before applying. It assumes the owner UID configured in the project. Do not leave the database open to all authenticated users.
- Existing owner-app code may have additional database paths or permissions. Test owner product sync and order status updates after applying rules.
- KPay transfers are not automatically verified. The app records the optional transaction ID and shows the payment account details; the shop owner must verify the transfer.
