CHAN SHOP Customer Android Project

ဒီ Project က Owner App နဲ့ သီးခြား install လုပ်နိုင်အောင် သီးခြား Android applicationId သတ်မှတ်ထားပါတယ်။

Owner App package: com.chanshop.app (သင်ပေးထားသော MainActivity.java အရ)
Customer App package: com.chanshop.customer

ထို့ကြောင့် ဖုန်းတစ်လုံးတည်းမှာ Owner App နဲ့ Customer App ကို နှစ်ခုလုံး install လုပ်နိုင်ပါတယ်။

APK မဟုတ်သေးပါ။ Android Studio သို့မဟုတ် Gradle build environment ဖြင့် APK ထုတ်ရပါမယ်။
Build: Android Studio မှာ ဒီ folder ကို Open လုပ်ပြီး Sync Now, ပြီးရင် Build > Build APK(s) ကိုနှိပ်ပါ.

Firebase:
- Email/Password Authentication ကို Enable လုပ်ထားရပါမယ်.
- Customer phone number ကို synthetic email (09xxxxxxxxx@customer.chan-shop.invalid) အဖြစ် map လုပ်ထားသည်။ SMS OTP မပို့ပါ၊ ဖုန်းနံပါတ်ပိုင်ရှင်ဖြစ်ကြောင်း အတည်မပြုပါ။
- API key သည် client app ထဲတွင် မြင်နိုင်သည်။ လုံခြုံရေးကို Database Rules ဖြင့် enforce လုပ်ရမည်။
- လက်ရှိ Database Rules auth != null read/write သည် production အတွက် မလုံခြုံပါ။ Public မဖြန့်မီ Customer များကို products read သာခွင့်ပေးပြီး orders ကို UID အလိုက်ကန့်သတ်ရန် Rules ပြင်ဆင်ပါ။
- Customer app မှာ order price ကို client ပေးပို့သည့်အတိုင်း ယူထားသောကြောင့် production မှာ server-side price validation မရှိဘဲ မဖြန့်ပါနှင့်။
